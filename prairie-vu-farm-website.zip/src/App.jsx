export default function App() {
  return (
    <div className="min-h-screen bg-[#fdfaf6] text-[#5a3e36] font-serif">
      <header className="bg-white p-6 shadow-md">
        <h1 className="text-4xl font-bold text-center">Prairie-Vu Farm</h1>
        <p className="text-center text-xl mt-2 italic">Where Country Charm Meets Elegant Celebrations</p>
      </header>

      <section className="p-8 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h2 className="text-3xl font-semibold mb-4">About the Venue</h2>
          <p className="text-lg leading-relaxed">
            Located in the heart of the prairie, Prairie-Vu Farm blends rustic charm with modern elegance. Our historic barn and sweeping open fields create the perfect backdrop for unforgettable weddings and events.
          </p>
        </div>
        <img src="https://images.unsplash.com/photo-1534949841653-5f09f8dbda55?auto=format&fit=crop&w=800&q=60" alt="Prairie-Vu Wedding" className="rounded-xl shadow-md" />
      </section>

      <section className="bg-white p-8">
        <h2 className="text-3xl font-semibold text-center mb-6">Wedding Packages</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="border p-6 rounded-xl shadow-sm">
            <h3 className="text-2xl font-bold mb-2">Prairie Package</h3>
            <p>Rustic tables & chairs, barn access, 100 guests, on-site parking.</p>
            <p className="mt-2 font-semibold">Starting at $3,500</p>
          </div>
          <div className="border p-6 rounded-xl shadow-sm">
            <h3 className="text-2xl font-bold mb-2">Sunset Celebration</h3>
            <p>Includes Prairie Package + upgraded seating, arbor, cocktail hour setup.</p>
            <p className="mt-2 font-semibold">Starting at $5,000</p>
          </div>
          <div className="border p-6 rounded-xl shadow-sm">
            <h3 className="text-2xl font-bold mb-2">Golden Hour Luxury</h3>
            <p>Full-day access, luxury rentals, florals, coordination, rehearsal dinner options.</p>
            <p className="mt-2 font-semibold">Starting at $7,200</p>
          </div>
        </div>
      </section>

      <section className="p-8">
        <h2 className="text-3xl font-semibold text-center mb-6">Contact Us</h2>
        <form className="max-w-xl mx-auto space-y-4">
          <input type="text" placeholder="Name" className="w-full p-3 border rounded-lg" />
          <input type="email" placeholder="Email" className="w-full p-3 border rounded-lg" />
          <textarea placeholder="Tell us about your event..." className="w-full p-3 border rounded-lg" rows={4}></textarea>
          <button className="bg-[#5a3e36] text-white px-6 py-3 rounded-lg hover:bg-opacity-90">Send Message</button>
        </form>
      </section>

      <footer className="bg-white p-6 text-center text-sm text-gray-600">
        © {new Date().getFullYear()} Prairie-Vu Farm. All rights reserved.
      </footer>
    </div>
  );
}